
/*
 * 
 * website: http://www.coolsoft-sd.com/
 * contact: support@coolsoft-sd.com
 *
 */

#include "stdafx.h"
#include "Course.h"

// Initializes course
Course::Course(int id, const string& name) : _id(id),
											 _name(name) { }

